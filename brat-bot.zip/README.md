# Brat Bot 🤖💅

This is a WhatsApp bot that turns your text into Brat-style stickers.

### How to use:
1. Import repo into Replit.
2. Click "Run".
3. Scan the QR code with WhatsApp Web (on your phone: Settings > Linked Devices > Link a Device).
4. Type `.brat your text` in any chat → bot replies with a sticker.

Enjoy ✨
