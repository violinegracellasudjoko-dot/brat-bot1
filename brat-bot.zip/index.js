
// Brat Bot - WhatsApp Sticker Bot
const { default: makeWASocket, useMultiFileAuthState, downloadMediaMessage } = require('@whiskeysockets/baileys');
const pino = require('pino');
const { Sticker, StickerTypes } = require('wa-sticker-formatter');

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');
    const sock = makeWASocket({
        auth: state,
        logger: pino({ level: 'silent' })
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message || !msg.key.remoteJid) return;

        const body = msg.message.conversation || msg.message.extendedTextMessage?.text;
        if (!body) return;

        if (body.startsWith('.brat')) {
            const text = body.replace('.brat', '').trim() || "brat";
            const sticker = new Sticker(undefined, {
                pack: 'BratBot',
                author: 'StickerBot',
                type: StickerTypes.FULL,
                background: '#FFC0CB',
                text: text,
                crop: false
            });

            await sock.sendMessage(msg.key.remoteJid, await sticker.toMessage(), { quoted: msg });
        }
    });
}

startBot();
